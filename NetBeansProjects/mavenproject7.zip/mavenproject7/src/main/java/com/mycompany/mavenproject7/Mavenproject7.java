/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.mavenproject7;

import java.util.Scanner;

/**
 *
 * @author Student
 */
public class Mavenproject7 {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        
        System.out.print("Enter the cutomer name: "); 
        String name = input.nextLine();
         
         
        
        System.out.print("Enter product name: ");
         String product = input.nextLine();
         
         
         
         System.out.print("Enter price of the product: ");
         int price = input.nextInt();
         
         
         System.out.print("Enter quantity puchased: ");
         int quantity = input.nextInt();
         
         
         System.out.print("\n---recipt----");
         
         double total = price * quantity; 
         double VAT = total * 0.15;
         double finalamount = total + VAT;
         
         
         
         
         
         
         
         
         
         
         
         
       
         
        
        
        
    
    
    
    }
}